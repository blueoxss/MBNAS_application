README.txt                      what each file is
    protocol/requested.json         the protocol the user submitted for validation (or the Run payload)
    protocol/resolved.json          the frozen resolved protocol; protocol/protocol_hash.txt its canonical hash
    manifests/hashes.json           train/search_val/final_eval/class-mapping hashes + counts (resolved + validation)
    manifests/<split_hash>.json     cached split manifests (sample ids, image/label sha256), when present
    evaluations.csv / .jsonl        every evaluation row incl. superseded history and failures (CSV = key columns)
    lineage.json                    candidates: parents, parent evaluation ids, lineage ops, blocks, architecture hash
    generations.json                generation rows (counts, closure, representative)
    cost_ledger.csv                 every ledger row (physical vs billed arm, failed/retry/profile)
    checkpoints.json                checkpoint rows (path, sha256, bytes, hashes, state PRESENT/PRUNED + prune record)
    artifacts.json                  artifact registry rows (run-relative paths + sha256)
    final_retrain.json              FINAL_RETRAIN run only: parent_run_id, frozen finalists + selection rule, budget
    final_retrain_children.json     SEARCH run with final-retrain children: child run ids, status, costs, finalists
                                    and the final results summary (rung FINAL rows on the final split)
    jobs.json                       job attempts/status/reason codes (no outputs bodies)
    events.jsonl                    the full run event log
    provenance.json                 source tree hash, canonicalization, validator, run identity, export time
    environment.lock.json           package/driver/GPU versions
    SHA256SUMS                      sha256 of every file above

Profile: public. ``public`` (default; the console ``GET /runs/{id}/export`` and the gateway's export
manifest) projects every member onto the public contract 1.5.0 (:mod:`mbnas_core.console.projection`; DTO allowlist
section 3.9): resolved protocol without realpath / pool root, evaluation rows and events as their public components
(run-relative checkpoint paths, raw_metrics allowlist, scrubbed log text, opaque worker / device ids), lineage and
blocks as the public lineage subset (repair folded), checkpoint rows without paths, artifact rows with public metadata
only, the cost ledger without internal row ids / device UUIDs / host row ids, provenance and final-retrain budgets
without the admission policy text, split manifests without host paths (sample ids + digests), the environment lock
without host name, interpreter path and GPU UUIDs. ``owner`` (``/core/v1/owner/runs/{id}/export``, scope admin) is
the raw bundle below, unchanged.
